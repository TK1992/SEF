package UnitTests;

import Game.Board;
import Game.Dice;
import Game.Player;
import junit.framework.TestCase;

public class PlayerTests extends TestCase {
Player player;
Board bd;
Dice dice;

static int roll;

	protected void setUp() throws Exception {
		player = new Player(bd, dice, 0, "John");
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	//success case for adding piece (between 1 - 3)
	public void testAddPiece(){
		player.addPiece(3);
		assertTrue(player.getNumberOfPieces() == 3);
	}
	// fail case, more than 3, less than 1
	public void testPieceCount(){
		Player testPlayer = new Player(bd, dice, 0, "John");
		testPlayer.addPiece(4);
		assertNull(player.getPieces());
		testPlayer.addPiece(0);
		assertNull(player.getPieces());
	}
	
	public void testRollDice(){
		roll = Dice.getThrow();
		assertEquals(true, roll >=1 || roll <=6);
	}
	
	public void testGetPiece(){
		
	}
	
	// get snake escape (max 3)
	public void testSnakeEscapePoints(){
		player.addEscapePoints();
		player.addEscapePoints();
		player.addEscapePoints();
		player.addEscapePoints();
		assertTrue(player.getSnakeEscapePoints() == 3);
	}
	
	
	public void testRegisterDetails(){
		
	}
	
	public void winCondition(){
		
	}
}
