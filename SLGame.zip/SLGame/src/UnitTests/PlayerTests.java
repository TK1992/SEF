package UnitTests;

import junit.framework.TestCase;

public class PlayerTests extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testAddPiece(){

	}
	
	public void testRollDice(){
		
	}
	
	public void testGetPiece(){
		
	}
	
	public void testSnakeEscapePoints(){
		
	}
	
	public void testRegisterDetails(){
		
	}
	
	public void winCondition(){
		
	}
}
