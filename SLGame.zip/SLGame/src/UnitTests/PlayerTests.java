package UnitTests;

import java.util.ArrayList;
import Game.Board;
import Game.Dice;
import Game.Player;
import junit.framework.TestCase;
import Game.Ladder;

public class PlayerTests extends TestCase {
	Player[] player = new Player[2];
	Board bd;
	Dice dice;
	ArrayList<Ladder> ls = new ArrayList<Ladder>();
	protected void setUp() throws Exception {
		bd = new Board();
		player[0] = new Player(bd, dice, 0, "Test");
		player[1] = new Player(bd, dice, 0, "Test");
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testAddSnakePoints(){
		player[0].addEscapePoints();
		ls = bd.getLadders();
		int pos = ls.get(0).getBottom();
		bd.newPos(pos, 0);
		assertEquals(2, player[0].getSnakeEscapePoints());
	}

	public void testGetPiece(){
		
	}
	
	public void testSnakeEscapePoints(){
		player[1].addEscapePoints();
		player[1].addEscapePoints();
		assertEquals(2, player[1].getSnakeEscapePoints());
		player[1].addEscapePoints();
		player[1].addEscapePoints();
		assertEquals(3, player[1].getSnakeEscapePoints());
	}
	
	public void testRegisterDetails(){
		
	}
	
	public void winCondition(){
		
	}
}
