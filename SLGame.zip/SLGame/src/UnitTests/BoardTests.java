package UnitTests;

import java.util.ArrayList;

import Game.Board;
import Game.Ladder;
import Game.Snake;
import junit.framework.TestCase;

public class BoardTests extends TestCase {
	Board bd;
	ArrayList<Ladder> ls = new ArrayList<Ladder>();
	ArrayList<Snake> ss = new ArrayList<Snake>();
	
	protected void setUp() throws Exception {
		bd = new Board();
		ls = bd.getLadders();
		ss = bd.getSnakes();
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testPlayerOnSnake(){
		int pos = 75;
		int val = bd.newPos(pos, 0);
		assertTrue(val == ss.get(0).getTail());
	}
	
	public void testPlayerOnLadder(){
		int pos = 12;
		int val = bd.newPos(pos,0);
		assertEquals("val = " + val + "ls = " + "ls.get(0).getTop()", ls.get(0).getTop(), val);
	}
}
