package UnitTests;

import java.util.ArrayList;

import Game.Board;
import Game.Ladder;
import Game.Player;
import Game.Snake;
import Game.SnakePlayer;
import Game.Dice;
import junit.framework.TestCase;

public class BoardTests extends TestCase {
	Board bd;
	ArrayList<Ladder> ls = new ArrayList<Ladder>();
	ArrayList<Snake> ss = new ArrayList<Snake>();
	Player[] players = new Player[1];
	Dice dice;
	
	protected void setUp() throws Exception {
		bd = new Board();
		dice = new Dice(bd.getGraphics());
		players[0] = new Player(bd, dice, 0, "Tom");
		ls = bd.getLadders();
		ss = bd.getSnakes();
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testPlayerOnSnake(){
		int pos = 75;
		int val = 0;
		if(pos == ss.get(0).getHead()){
			val = ss.get(0).getTail();
		}
		assertTrue(val == ss.get(0).getTail());
	}
	
	public void testPlayerOnLadder(){
		int pos = 12;
		int val = 0;
		if(pos == ls.get(0).getBottom()){
			val = ls.get(0).getTop();
		}
		assertEquals("val = " + val + "ls = " + "ls.get(0).getTop()", ls.get(0).getTop(), val);
	}
	
	public void testAddSnakePlayer(){
		int pos = 75;
		SnakePlayer snakePlayer = new SnakePlayer(20, 3, players[0], ss.get(0));
		if(pos == ss.get(0).getHead()){
			bd.addSnakePlayer(players[0], 0);
			assertEquals(snakePlayer.getHead(), bd.getSnakePlayers().get(0).getHead());
		} else {
			assertEquals(1, 0);
		}
		
	}
}
