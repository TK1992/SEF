package UnitTests;

import Game.Board;
import Game.Ladder;
import Game.Snake;
import junit.framework.TestCase;

public class BoardTests extends TestCase {
	Board bd;
	Ladder[] ls;
	Snake[] ss;
	static int snk;
	protected void setUp() throws Exception {
		bd = new Board();
		ls = bd.getLadders();
		ss = bd.getSnakes();
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testPlayerOnSnake(){
		int pos = 75;
		int val = bd.newPos(pos, 0);
		assertTrue(val == ss[0].getTail());
	}
	
	public void testPlayerOnLadder(){
		int pos = 12;
		int val = bd.newPos(pos,0);
		assertTrue(val == ls[0].getTop());
	}
	
	// test player does not go up snake from tail
	public void testNoBottom(){
		// int pos = ss[0].getTail();
		int pos = 42;
		int val = bd.newPos(pos,0);
		assertTrue(val == ss[0].getTail());
	}
	
	public void testSnakePos() {
		snk = Snake.getX(snk);
		assertEquals(true, snk >=10 || snk <= 80);
	}

	// Snake can't go on pos 100
	public void snakePos(){
		/*int head = 100;
		int pos = Snake.getMax() <= 80 );
		assert */
		
	}
	
	// 
	public void createSnakePlayer() {
	
	}
	
	public void destroySnakePlayer() {
		
	}
	
	
}
