package UnitTests;

import junit.framework.TestCase;
import Game.Board;
import Game.Dice;

public class DiceTests extends TestCase {
	Board bd;
	static int output;
	protected void setUp() throws Exception {
		bd = new Board();
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	public void testRoll() {
		output = Dice.getThrow();
		assertEquals(6, output);
	}
	public void testRollSet() {
		output = Dice.getThrow();
		assertEquals(true, output >= 1 || output <= 6);
	}
}
