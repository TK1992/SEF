package UnitTests;

import junit.framework.TestCase;
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;
import Game.Board;
import Game.Snake;

import junit.framework.TestCase;

public class SnakeTests extends TestCase {
	Board bd;
	Snake[] ss;
	protected void setUp() throws Exception {
		bd = new Board();
		ss = bd.getSnakes();
		super.setUp();
	}
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	public void testSnakeAddPass(){
		assertTrue(bd.checkBoardPosition(10, 25));
	}
	public void testSnakeAddFailed(){
		assertFalse(bd.checkBoardPosition(12, 49));
	}
	public void testSnakeChange(){
		/*for(int i = 0; i < ss.length; i++){
			assertEquals(ss[i].change(), ss[i].getTail() - ss[i].getHead());
		} */
		assertEquals(ss[0].change(), ss[0].getTail() - ss[0].getHead());
	}
	public void testDefaultSnakeMax(){
		int head = 79;
		assertTrue(head <= Snake.getMax());
	}
	
	public void testDefaultSnakeMin(){
		int tail = 2;
		assertTrue(tail >= Snake.getMin());
	}
}
