package UnitTests;

import junit.framework.TestCase;
import java.util.*;
import org.junit.*;
import static org.junit.Assert.*;
import Game.Board;
import Game.Ladder;

public class LadderTests extends TestCase {
	Board bd;
	Ladder[] ls;
	
	protected void setUp() throws Exception {
		bd = new Board();
		ls = bd.getLadders();
		super.setUp();
	}
	protected void tearDown() throws Exception {
		super.tearDown();
	}
	public void testLadderAddPass(){
		assertTrue(bd.checkBoardPosition(10, 25));
	}
	public void testLadderAddFailed(){
		assertFalse(bd.checkBoardPosition(12, 49));
	}
	public void testLadderChange(){
		/* for(int i = 0; i < ls.length; i++){
			assertEquals(ls[i].change(), ls[i].getTop() - ls[i].getBottom());
		} */
		assertEquals(ls[0].change(), ls[0].getTop() - ls[0].getBottom());
	}
	public void testDefaultLadderMax(){
		int top = 79;
		assertTrue(top <= Ladder.getMax());
	}
	
	public void testDefaultLadderMin(){
		int bottom = 2;
		assertTrue(bottom <= Ladder.getMin());
	}
}
