package UnitTests;

import Game.LogIn;
import Game.SLGame;
import junit.framework.TestCase;

public class LogInTest extends TestCase {
	
	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testLoginPass(){
		LogIn login = new LogIn();
		assertTrue(login.attemptLogIn("Tom", "Tom123"));
	}
	
	public void testLoginFail(){
		LogIn login = new LogIn();
		assertFalse(login.attemptLogIn("Rohit", "Rohit23"));
	}
	
	public void testLoginLengthFail(){
		LogIn login = new LogIn();
		//test below to check if false is returned when username contains symbols
		assertFalse(login.validateRegistrationDetails("Rohit!%", "Rohit123"));
		
		//test below to check if false is returned when username is less than minimum length
		assertFalse(login.validateRegistrationDetails("R", "Rohit23"));
		
		//test below to check if false is returned when username is more  than maximum length
		assertFalse(login.validateRegistrationDetails("Rohitrohitrohit", "Rohit23"));
		
		//test below to check if false is returned when password is more  than maximum length
		assertFalse(login.validateRegistrationDetails("Rohit", "Rohit233223423423"));
		
		//test below to check if false is returned when password is less than minimum length
		assertFalse(login.validateRegistrationDetails("Rohit", "R2"));
	}
	public void testwriteToFile(){
		
	}
	
	public void testReadFile(){
		
	}
}
