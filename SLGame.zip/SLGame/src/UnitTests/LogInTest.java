package UnitTests;

import Game.LogIn;
import Game.SLGame;
import junit.framework.TestCase;

public class LogInTest extends TestCase {
	
	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testLoginPass(){
		LogIn login = new LogIn();
		assertTrue(login.attemptLogIn("Tom", "Tom123"));
	}
	
	public void testLoginFail(){
		LogIn login = new LogIn();
		assertFalse(login.attemptLogIn("Rohit", "Rohit23"));
	}
	
	public void testwriteToFile(){
		
	}
	
	public void testReadFile(){
		
	}
}
