package UnitTests;

import junit.framework.TestCase;
import Game.Snake;
import Game.SnakePlayer;

public class SnakePlayerTests extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testCoordinatePass(){
		int[] points = new int[2];
		points = SnakePlayer.calculateSnakePlayerPoints();
		assertTrue(points[0] <= Snake.getMax() && points[0] > Snake.getMin());
		assertTrue(points[1] <= Snake.getMax() && points[1] > Snake.getMin());
		assertTrue(points[0] > points[1]);
	}
	
	public void testCoordinateFail(){
		int[] points = new int[2];
		points = SnakePlayer.calculateSnakePlayerPoints();
		assertFalse(points[0] > Snake.getMax() && points[0] <= Snake.getMin());
		assertFalse(points[1] > Snake.getMax() && points[1] <= Snake.getMin());
		assertFalse(points[0] < points[1]);
	}
}
