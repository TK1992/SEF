package UnitTests;

import junit.framework.TestCase;
import Game.Player;
import Game.Snake;
import Game.SnakePlayer;
import Game.Board;
import Game.Dice;

public class SnakePlayerTests extends TestCase {
	Board bd;
	Dice dice;
	int index;
	String name;
	protected void setUp() throws Exception {
		bd = new Board();
		dice = new Dice(bd.getGraphics());
		index = 0;
		name = "Test";
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public void testCoordinatePass(){
		int[] points = new int[2];
		points = SnakePlayer.calculateSnakePlayerPoints();
		assertTrue(points[0] <= Snake.getMax() && points[0] > Snake.getMin());
		assertTrue(points[1] <= Snake.getMax() && points[1] > Snake.getMin());
		assertTrue(points[0] > points[1]);
	}
	
	public void testCoordinateFail(){
		int[] points = new int[2];
		points = SnakePlayer.calculateSnakePlayerPoints();
		assertFalse(points[0] > Snake.getMax() && points[0] <= Snake.getMin());
		assertFalse(points[1] > Snake.getMax() && points[1] <= Snake.getMin());
		assertFalse(points[0] < points[1]);
	}
	
	public void testHeadMovement(){
		Snake snake = new Snake(60,50);
		Player player = new Player(bd, dice, index, name);
		SnakePlayer sp = new SnakePlayer(20, 5, player, snake, bd, dice);
		int head = sp.getHead();
		int tail = sp.getTail();
		sp.move();
		assertTrue(sp.getHead() > head);
		assertTrue(sp.getTail() == tail);
	}
}
