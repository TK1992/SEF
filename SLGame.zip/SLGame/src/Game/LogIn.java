package Game;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.HashMap;
//import java.util.Map;

public class LogIn {
	
	HashMap<String, String> TestUsers = new HashMap<String, String>();
	
	public LogIn(){
	}
	// Handles login code, and breaks on successful login.
	public void loginHandler(){
		//File file;
		//HashMap<String, String> UsersMap = new HashMap<String, String>();
		//UsersMap = readUserFile(file, UsersMap);
		Scanner sc = new Scanner(System.in);
		System.out.print("Please Enter Username: ");
		String username = sc.nextLine();
		System.out.print("Please Enter Password: ");
		String password = sc.nextLine();
		while(attemptLogIn(username, password) == false){
			// Error message / any other code if needed.
			System.out.print("Please Enter Username: ");
			username = sc.nextLine();
			System.out.print("Please Enter Password: ");
			password = sc.nextLine();
		}
		//sc.close(); ERROR DUE TO STATIC SCANNER?
	}
	// Try and login, compare input to array.
	public boolean attemptLogIn(String username, String password){
		TestUsers.put("Tom", "Tom123");
		TestUsers.put("John", "John123");
		TestUsers.put("Rohit", "Rohit123");
		for(String key : TestUsers.keySet()){
			if(username.compareTo(key) == 0) {
				if(password.compareTo(TestUsers.get(key)) == 0){
					return true;
				}
			}
		}
		/*if(username.compareTo("test") == 0 && password.compareTo("test") == 0){
			return true;
		} */
		System.out.println("Incorrect username or password.");
		return false;
	}
	// Store User Details in temp array, inside this function. Use Strtok!
	public HashMap<String, String> readUserFile(File file, HashMap<String,String> UsersMap){
		BufferedReader br = null;
			try{
				
			}catch (Exception e){
				
			}
		return UsersMap;
	}	
	
	public void writeToUserFile(File file) throws IOException {
		BufferedWriter bw = new BufferedWriter(new FileWriter(file, true));
			try {
				
			} catch (Exception e) {
				
			}
	}
}
