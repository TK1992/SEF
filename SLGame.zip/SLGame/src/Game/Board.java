package Game;
import java.awt.*;
import javax.swing.*;
import java.util.*;

public class Board extends JPanel implements Runnable
{
   static Scanner scan = new Scanner(System.in);
   private static JFrame frame = new JFrame("Assignment Demo");
   private int XMARGIN = 20;
   private int YMARGIN = 20;
   private Player players[];
   private int pCount;

   private Snake[] ss = new Snake[10];
   private Ladder[]ls = new Ladder[10];
   private ArrayList<SnakePlayer> snakePlayers;
   int snakesCount = 0;
   int laddersCount = 0;

   public Ladder[] getLadders(){
	   return ls;
   }
   public Snake[] getSnakes(){
	   return ss;
   }
   // the standard positions of snakes and ladders
   public void setup()
   {
      add(new Ladder(12,49));
      add(new Ladder(34,51));
      add(new Ladder(53,79));

      add(new Snake(75,42));
      add(new Snake(39,8));
      add(new Snake(95,21));
      add(new Snake(42,19));  //Use ArrayList to Manipulate.
   }

   // allows the number and positions of snakes and ladders to be customized
   public void customize()
   {
 
     snakesCount = 0;
     laddersCount = 0;
     repaint();
     int numSnakes;
     int numLadders;

     do {
        System.out.print("Enter number of snakes : 1..10 : ");
        numSnakes = scan.nextInt();  
        System.out.print("Enter number of ladders : 1..10 : ");
        numLadders = scan.nextInt();  
     } while ( numSnakes < 1 || numSnakes > 10 || numLadders < 1 && numLadders > 10);
     for (int i=0; i<numSnakes; i++)
     {
        int head,tail;
        do {
          System.out.print("Enter Head pos of snake " + (i+1) + " : ");
          head = scan.nextInt();
          System.out.print("Enter Tail pos of snake " + (i+1) + " : ");
          tail = scan.nextInt();
          if ( tail >= head)
             System.out.println("Head must be higher than the tail. ReEnter"); 
        } while ( head <= tail);
        if(snakesCount == 0 || checkBoardPosition(tail, head) == true){
        	if(head <= Snake.getMax() && tail >= Snake.getMin()){
        		ss[i] = new Snake(head,tail);
        		add(new Snake(head,tail));
        	} else {
        		System.out.println("Snake must be placed within squares 1- 80");
        		i--;
        	}
        } else {
        	System.out.println("A Snake or Ladder is already placed here."); 
        	i--;
        }
     }     
     for (int i=0; i<numLadders; i++)
     {
        int bottom,top;
        do {
          System.out.print("Enter Bottom pos of ladder " + (i+1) + " : ");
          bottom = scan.nextInt();
          System.out.print("Enter Top pos of ladder " + (i+1) + " : ");
          top = scan.nextInt();
          if ( bottom >= top)
             System.out.println("Top must be higher than the Bottom. ReEnter"); 
        } while ( top <= bottom);
        if(laddersCount == 0 || checkBoardPosition(bottom, top) == true){
        	if(bottom >= Ladder.getMin() && top <= Ladder.getMax()){
        		ls[i] = new Ladder(bottom,top);
        		add(new Ladder(bottom,top));
        	} else {
        		System.out.println("Snake must be placed within squares 1- 80");
        		i--;
        	}
        } else {
        	 System.out.println("A Snake or Ladder is already placed here."); 
        	 i--;
        }
     }    
   }
   public boolean checkBoardPosition(int bottomPosition, int topPosition){
  	   for(int i = 0; i < laddersCount; i++){
  		   if(ls[i].getBottom() == bottomPosition || ls[i].getTop() == topPosition){
  			   return false;
  		   } 
  	   }
  	   for(int i = 0; i < snakesCount; i ++){
  		   if(ss[i].getHead() == topPosition || ss[i].getTail() == bottomPosition){
  			   return false;
  		   	}
  	   		}
	   return true;
   }
   
   public void addSnakePlayer(int index){
	   
   }
   // Computes the new position taking into account the positions of the snakes and ladders
   public int newPos(int pos, int index)
   { 
       int val = pos;
       for (int i=0; i<laddersCount; i++)
           if ( pos == ls[i].getBottom() )
              val = ls[i].getTop();

       for (int i=0; i<snakesCount; i++)
           if ( pos == ss[i].getHead() )
              val = ss[i].getTail();

       if ( val < pos)
       {
           System.out.println("You are bitten by a snake. Press 1 to continue");
           //scan.nextInt();
           addSnakePlayer(index);
       }        
       else if ( val > pos)
       {
           System.out.println("You are going up the ladder. Press 1 to continue");
           players[index].addEscapePoints();
           //scan.nextInt();
       }        
       return val;
   }


   public void add(Snake s)
   {
      if ( snakesCount < 10)
      {
          ss[snakesCount] = s;
          snakesCount++;
      }
   }
      
   public void add(Ladder l)
   {
      if ( laddersCount < 10)
      {
          ls[laddersCount] = l;
          laddersCount++;
      }
   }


   public Board()
   {
	Container contentPane = frame.getContentPane();
      contentPane.setLayout(new BorderLayout());
	
      frame.getContentPane().add(this,BorderLayout.CENTER);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(640,520);
      frame.setVisible(true);
      setup();
      new Thread(this).start();
   }
   

   public void add(Player players[], int pCount)
   {
      this.players = players;
      this.pCount = pCount; 
      
      for(int i = 1; i <= pCount; i++){
    	  System.out.print("Please enter number or pieces desired for player " + i + ": ");
    	  int pieceCount = scan.nextInt();
    	  	for(int j = 1; j <= pieceCount; j++){
    	  		this.players[i - 1].addPiece(pieceCount);
    	  	}
      }
   }

   // This method is used to wiggle the snake
   // The timing can be changed by varying the sleep time
   public void run()
   {
      double inc = 0.05;
      while (true)
      {
        try {
          Thread.sleep(1000);
        }
        catch (Exception e) {}
        Draw.factor += inc;; 
        if (Draw.factor > 0.5 || Draw.factor < -0.5)
           inc = -inc;
        repaint();
      }
   }

   // this method is called in response to repaint 
   public void paintComponent(Graphics g) {

      super.paintComponent(g);
      for (int i=0; i<10; i++)
         for (int j=0; j<10; j++){
           if ((i+j)%2 == 0) 
              g.setColor(Color.YELLOW);
           else 
              g.setColor(Color.ORANGE);          
           g.fillRect(XMARGIN + 40*i,YMARGIN+40*j, 40,40);
	     }
      g.setColor(Color.BLACK);
      for ( int i=0; i<100; i++)    
      if ( (i/10) % 2 == 0 )         
	  	  g.drawString("" + (i+1),XMARGIN + 5 + i%10 * 40 ,YMARGIN -5 + 400 - i/10 * 40);
             else
		  g.drawString("" + (i+1),XMARGIN  + 370 - (i%10 * 40) ,YMARGIN - 5 + 400 - i/10 * 40);
   
      for (int i=0; i<snakesCount; i++)
         ss[i].draw(g);
      for (int i=0; i<laddersCount; i++)
         ls[i].draw(g);
      for (int i=0; i<pCount; i++){
    	  //Pieces[] pieces = players[i].getPieces();
    	  //for(int j = 0; j < players[i].getNumberOfPieces(); i++){
    		  players[i].draw(g); 
    		  //pieces[j].draw(g);
        // }
   }
   }
}