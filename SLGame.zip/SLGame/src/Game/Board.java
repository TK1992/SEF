package Game;
import java.awt.*;
import javax.swing.*;
import java.util.*;

public class Board extends JPanel implements Runnable
{
   static Scanner scan = new Scanner(System.in);
   private static JFrame frame = new JFrame("Snakes And Ladders");
   private int XMARGIN = 20;
   private int YMARGIN = 20;
   private Player players[];
   private int pCount;

   private ArrayList<Snake> ss = new ArrayList<Snake>();
   private ArrayList<Ladder> ls = new ArrayList<Ladder>();
   private ArrayList<SnakePlayer> snakePlayers = new ArrayList<SnakePlayer>();
   private int snakesCount = 0;
   private final int MIN_SNAKES = 4;
   private final int MAX_SNAKES = 8;
   private int laddersCount = 0;
   private Dice dice;

   public ArrayList<Ladder> getLadders(){
	   return ls;
   }
   public ArrayList<Snake> getSnakes(){
	   return ss;
   }
   public ArrayList<SnakePlayer> getSnakePlayers(){
	   return snakePlayers;
   }
   
   public void setDice(Dice dice){
	   this.dice = dice;
   }
   // the standard positions of snakes and ladders
   public void setup()
   {
	  ls.add(0, new Ladder(12,49));
	  add(ls.get(0));
	  ls.add(1, new Ladder(34,51));
	  add(ls.get(1));
	   
	  ss.add(0, new Snake(75,42));
	  add(ss.get(0));
      ss.add(1, new Snake(39,8));
      add(ss.get(1));
      ss.add(2, new Snake(95,21));
      add(ss.get(2));
      ss.add(3, new Snake(42,19));  
      add(ss.get(3));
      /*ss.add(4, new Snake(6,1));  
      add(ss.get(4)); */
   }
   //To implement.
   public int[] averagePlayerInput(){
	  int avgSnakes = 0;
	  int avgLadders = 0;
	  int numSnakes, numLadders;
	  for(int i = 0; i <pCount; i++){ 
	  do {
	        System.out.print("Enter number of snakes : 4..8 : ");
	        numSnakes = scan.nextInt();  
	        System.out.print("Enter number of ladders : 2..6 : ");
	        numLadders = scan.nextInt();  
	     } while (!(numSnakes >= MIN_SNAKES && numSnakes <= MAX_SNAKES) && !(numLadders >= MIN_SNAKES - 2 && numLadders <= MAX_SNAKES - 2));
	  avgSnakes += numSnakes;
	  avgLadders += numLadders;
	  }
	  int[] objects = new int[2];
	  objects[0] = avgSnakes/pCount;
	  objects[1] = avgLadders/pCount;
	  return objects;
   }
   
   // allows the number and positions of snakes and ladders to be customized
   public void customize()
   {
	 snakesCount = 0;
	 laddersCount = 0;
	 ls.clear();
	 ss.clear();
	 int numSnakes;
     int numLadders;
     do {
        System.out.print("Enter number of snakes : 4..8 : ");
        numSnakes = scan.nextInt();  
        System.out.print("Enter number of ladders : 2..6 : ");
        numLadders = scan.nextInt();  
     } while (!(numSnakes >= MIN_SNAKES && numSnakes <= MAX_SNAKES) && !(numLadders >= MIN_SNAKES - 2 && numLadders <= MAX_SNAKES - 2));
     for (int i=0; i<numSnakes; i++)
     {
        int head,tail;
        do {
          System.out.print("Enter Head pos of snake " + (i+1) + " : ");
          head = scan.nextInt();
          System.out.print("Enter Tail pos of snake " + (i+1) + " : ");
          tail = scan.nextInt();
          if ( tail >= head)
             System.out.println("Head must be higher than the tail. ReEnter"); 
        } while ( head <= tail);
        if(snakesCount == 0 || checkBoardPosition(tail, head) == true){
        	if(head <= Snake.getMax() && tail >= Snake.getMin()){
        		ss.add(i, new Snake(head,tail));
        		add(ss.get(i));
        	} else {
        		System.out.println("Snake must be placed within squares 1- 80");
        		i--;
        	}
        } else {
        	System.out.println("A Snake or Ladder is already placed here."); 
        	i--;
        }
     }     
     for (int i=0; i<numLadders; i++)
     {
        int bottom,top;
        do {
          System.out.print("Enter Bottom pos of ladder " + (i+1) + " : ");
          bottom = scan.nextInt();
          System.out.print("Enter Top pos of ladder " + (i+1) + " : ");
          top = scan.nextInt();
          if ( bottom >= top)
             System.out.println("Top must be higher than the Bottom. ReEnter"); 
        } while ( top <= bottom);
        if(laddersCount == 0 || checkBoardPosition(bottom, top) == true){
        	if(bottom >= Ladder.getMin() && top <= Ladder.getMax()){
        		ls.add(i, new Ladder(bottom,top));
        		add(ls.get(i));
        	} else {
        		System.out.println("Snake must be placed within squares 1- 80");
        		i--;
        	}
        } else {
        	 System.out.println("A Snake or Ladder is already placed here."); 
        	 i--;
        }
     }    
   }
   public boolean checkBoardPosition(int bottomPosition, int topPosition){
  	   for(int i = 0; i < laddersCount; i++){
  		   if(ls.get(i).getBottom() == bottomPosition || ls.get(i).getTop() == topPosition || ls.get(i).getBottom() == topPosition || ls.get(i).getTop() == bottomPosition){
  			   return false;
  		   } 
  	   }
  	   for(int i = 0; i < snakesCount; i++){
  		   if(ss.get(i).getHead() == topPosition || ss.get(i).getTail() == bottomPosition || ss.get(i).getHead() == bottomPosition || ss.get(i).getTail() == topPosition){
  			   return false;
  		   	}
  	   		}
	   return true;
   }
   
   public void addSnakePlayer(Player players, int snakeIndex){
	  //get two random integers from in an array from calculateSnakePlayerPoints();
	  int[] points = SnakePlayer.calculateSnakePlayerPoints();
	  SnakePlayer tempSnake = new SnakePlayer(points[0], points[1], players, ss.get(snakeIndex), this, dice);
	  snakePlayers.add(tempSnake);
	  SLGame.addSnakePlayer(tempSnake);
   }
   
   // Computes the new position taking into account the positions of the snakes and ladders
   public int newPos(int pos, Player player)
   { 
       int val = pos;
       for (int i=0; i<laddersCount; i++){
           if ( pos == ls.get(i).getBottom() ){
              val = ls.get(i).getTop();
              System.out.println("You are going up the ladder.");
              player.addEscapePoints();
              break;
           }
       }
       //check if piece lands on snake tail, and destroy snake and all of its snakePlayers.
       for (int i=0; i<snakesCount; i++){
           if (pos == ss.get(i).getHead() ){
              if(player.getSnakeEscapePoints() == 0){
		    	  val = ss.get(i).getTail();
		          System.out.println("You are bitten by a snake.");
		          addSnakePlayer(player, i);
		          player.consumePiece();
              }  else {
            	  player.setSnakeEscapePoints(player.getSnakeEscapePoints() - 1);
            	  System.out.println("You now have " + player.getSnakeEscapePoints() + "Snake Escape Points.");
              }
              break;
           }
       }
       //Check if it lands on snakePlayer head or tail. Destroy if head, move down but do not create new SP.
       return val;
   }
   public int newPos(int pos, SnakePlayer snakePlayer){
	   int val = pos;
	   		for(int i = 0; i < pCount; i++){
	   			//if it hits piece that is not owned by SP, consume. Else, stay.
	   		}
	   		for(int i = 0; i < snakesCount; i++){
	   			//If it lands on a snakes head, roll again.
	   		}
	   		for(int i = 0; i < snakePlayers.size(); i++){
	   			//Lands on ANOTHER snake players head, move again.
	   		}
	   return val;
   }

   public void add(Snake s)
   {
      if ( snakesCount < MAX_SNAKES)
      {
          snakesCount++;
      }
   }
      
   public void add(Ladder l)
   {
      if ( laddersCount < MAX_SNAKES - 2)
      {
          laddersCount++;
      }
   }


   public Board()
   {
	Container contentPane = frame.getContentPane();
      contentPane.setLayout(new BorderLayout());
	
      frame.getContentPane().add(this,BorderLayout.CENTER);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setSize(640,520);
      frame.setVisible(true);
      setup();
      new Thread(this).start();
   }
   

   public void add(Player players[], int pCount)
   {
      this.players = players;
      this.pCount = pCount; 
      
      for(int i = 1; i <= pCount; i++){
    	  System.out.print("Please enter number or pieces desired for player " + i + ": ");
    	  int pieceCount = scan.nextInt();
    	  		this.players[i - 1].addPiece(pieceCount);
      }
   }

   // This method is used to wiggle the snake
   // The timing can be changed by varying the sleep time
   public void run()
   {
      double inc = 0.05;
      while (true)
      {
        try {
          Thread.sleep(1000);
        }
        catch (Exception e) {}
        Draw.factor += inc;; 
        if (Draw.factor > 0.5 || Draw.factor < -0.5)
           inc = -inc;
        repaint();
      }
   }

   // this method is called in response to repaint 
   public void paintComponent(Graphics g) {

      super.paintComponent(g);
      for (int i=0; i<10; i++)
         for (int j=0; j<10; j++){
           if ((i+j)%2 == 0) 
              g.setColor(Color.YELLOW);
           else 
              g.setColor(Color.ORANGE);          
           g.fillRect(XMARGIN + 40*i,YMARGIN+40*j, 40,40);
	     }
      g.setColor(Color.BLACK);
      for ( int i=0; i<100; i++)    
      if ( (i/10) % 2 == 0 )         
	  	  g.drawString("" + (i+1),XMARGIN + 5 + i%10 * 40 ,YMARGIN -5 + 400 - i/10 * 40);
             else
		  g.drawString("" + (i+1),XMARGIN  + 370 - (i%10 * 40) ,YMARGIN - 5 + 400 - i/10 * 40);
   
      for (int i=0; i<snakesCount; i++)
         ss.get(i).draw(g);
      for (int i=0; i<laddersCount; i++)
         ls.get(i).draw(g);
      for (int i=0; i<pCount; i++)
    	players[i].draw(g); 
      for(int i=0; i<snakePlayers.size(); i++){
    	  snakePlayers.get(i).draw(g);
      }
   }
}