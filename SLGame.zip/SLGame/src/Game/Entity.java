package Game;

// Common abstract superclass for Snake and Ladder
abstract class Entity extends Draw
{
	   abstract int change();
}