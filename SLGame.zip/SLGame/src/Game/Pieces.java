package Game;
import java.awt.*;

public class Pieces extends Draw {
	private int index;
	private int pos;
	private int pieceNumber;
	private Player player;
	
	public Pieces(Player player, int pos, int index, int pieceNumber){
		this.index = index;
		this.pos = pos;
		this.pieceNumber = pieceNumber;
		this.player = player;
	}
	
	public int computePos(int val, Board bd)
	{
		if ( pos + val <= 100)
	      {
	         pos += val;      
	      }
	      pos = bd.newPos(pos, index);
	      return pos;
	}
	   
	public void draw(Graphics g){
		if (index == 0)
	      {
	         g.setColor(Color.WHITE);   
	         g.fillOval((int)getX(pos)-10,getY(pos)-10,20,20); 
	         g.setColor(Color.BLACK);   
	         g.drawString("1",(int)getX(pos)-5,getY(pos)+5); 
	      }
	      if (index == 1)
	      {
	         g.setColor(Color.RED);   
	         g.fillOval((int)getX(pos)+10,getY(pos)-10,20,20); 
	         g.setColor(Color.BLACK);   
	         g.drawString("2",(int)getX(pos)+15,getY(pos)+5); 
	      }
	      if (index == 2)
	      {
	         g.setColor(Color.BLUE);   
	         g.fillOval((int)getX(pos)-10,getY(pos)+10,20,20); 
	         g.setColor(Color.BLACK);   
	         g.drawString("3",(int)getX(pos)-5,getY(pos)+25); 
	      }
	      if (index == 3)
	      {
	         g.setColor(Color.CYAN);   
	         g.fillOval((int)getX(pos)+10,getY(pos)+10,20,20); 
	         g.setColor(Color.BLACK);   
	         g.drawString("4",(int)getX(pos)+15,getY(pos)+25); 
	      }
	}
}
