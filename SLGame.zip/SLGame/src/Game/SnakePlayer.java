package Game;
import java.awt.*;
public class SnakePlayer extends Snake {
	int h, t;
	Player playerFrom; //for creation
	Snake snakeFrom; //for creation
	
	public SnakePlayer(int h, int t){
		super(h, t);
		this.h = h;
		this.t = t;
	}
	public Player getPlayerFrom(){
		return playerFrom;
	}
	
	public Snake getSnakeFrom(){
		return snakeFrom;
	}
	
	public int move(){
		return 0;
	}
	
	
}
