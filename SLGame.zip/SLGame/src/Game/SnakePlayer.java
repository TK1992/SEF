package Game;
import java.awt.*;
import java.util.Scanner;
import java.math.*;
public class SnakePlayer extends Snake {
	private int head, tail;
	private Board bd;
	private Dice dice;
	private Player playerFrom; //for creation
	private Snake snakeFrom; //for creation
	static Scanner scan = new Scanner(System.in);
	
	public SnakePlayer(int h, int t, Player playerFrom, Snake snakeFrom, Board bd, Dice dice){
		super(h, t);
		this.head = h;
		this.tail = t;
		this.playerFrom = playerFrom;
		this.snakeFrom = snakeFrom;
		this.bd = bd;
		this.dice = dice;
	}
	public Player getPlayerFrom(){
		return playerFrom;
	}
	
	public Snake getSnakeFrom(){
		return snakeFrom;
	}
	
	public int move(){
		String resp;
	      int val;
	      do {
	         System.out.print("Press Enter to throw dice ");
	         resp = scan.nextLine();
	         System.out.println("Rolling the dice .... Please wait");
	         val = dice.roll();
	         System.out.println("You threw a " + val);
	         int pos = computePos(val, bd);	// computes the new position based on the dice value  
	         bd.repaint();		// causes the board and pieces to be redrawn
	         System.out.println("snake player " + playerFrom.getName() + " is now at position " + pos);   
	         if (pos == 100)
	            return 0;	// returns the index of the player winning the game
	         if (val == 6)
	            System.out.println("You get to throw again");
	      } while (val == 6); 
	      return -1;
	}
	
	public int computePos(int val, Board bd){
		if ( head + val <= 100)
	      {
	         head += val;
	      }
	      head = bd.newPos(head, this);
	      super.setHead(head);
	      return head;
	}
	
	 public static int[] calculateSnakePlayerPoints(){
		   int[] points = new int[2];
		   points[0] = (int) (Math.random()*Snake.getMax()+1);
		   points[1] = (int) (Math.random()*Snake.getMax()+1);
			while(points[1]>=points[0]){
				points[0] = (int) (Math.random()*Snake.getMax()+1);
				points[1] = (int) (Math.random()*Snake.getMax()+1);
			}
			return points;
	  }
	 
}
