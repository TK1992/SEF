package Game;
import java.awt.*;
public class SnakePlayer extends Snake {
	private int h, t;
	private Board bd;
	private Dice dice;
	private Player playerFrom; //for creation
	private Snake snakeFrom; //for creation
	
	public SnakePlayer(int h, int t, Player playerFrom, Snake snakeFrom, Board bd, Dice dice){
		super(h, t);
		this.h = h;
		this.t = t;
		this.playerFrom = playerFrom;
		this.snakeFrom = snakeFrom;
		this.bd = bd;
		this.dice = dice;
	}
	public Player getPlayerFrom(){
		return playerFrom;
	}
	
	public Snake getSnakeFrom(){
		return snakeFrom;
	}
	
	public int move(){
		return 0;
	}
}
